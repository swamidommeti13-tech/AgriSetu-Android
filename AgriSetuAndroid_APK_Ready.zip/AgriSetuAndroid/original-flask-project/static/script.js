const form = document.getElementById("bookingForm");

function setText(id, value) {
  document.getElementById(id).textContent = value;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const data = {
    farmer_name: document.getElementById("farmer_name").value.trim(),
    mobile: document.getElementById("mobile").value.trim(),
    village: document.getElementById("village").value.trim(),
    crop: document.getElementById("crop").value,
    quantity: document.getElementById("quantity").value,
    centre: document.getElementById("centre").value,
    booking_date: document.getElementById("booking_date").value
  };

  try {
    const res = await fetch("/api/book", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(data)
    });
    const result = await res.json();

    if (!result.success) {
      alert(result.message);
      return;
    }

    document.getElementById("result").style.display = "block";
    setText("token", result.token);
    setText("r_id", result.booking_id);
    setText("r_farmer", data.farmer_name);
    setText("r_crop", data.crop);
    setText("r_quantity", data.quantity);
    setText("r_centre", data.centre);
    setText("r_date", data.booking_date);
    setText("r_queue", result.queue_position);
    setText("r_wait", result.estimated_wait);
    setText("r_status", result.status);

    document.getElementById("status_id").value = result.booking_id;
    document.getElementById("result").scrollIntoView({behavior:"smooth"});
  } catch (err) {
    alert("Backend connection error. Please make sure python app.py is running.");
  }
});

async function checkStatus() {
  const id = document.getElementById("status_id").value;
  const box = document.getElementById("statusResult");

  if (!id) {
    box.innerHTML = "❌ Enter Booking ID";
    return;
  }

  try {
    const res = await fetch(`/api/status/${id}`);
    const data = await res.json();

    if (!data.success) {
      box.innerHTML = "❌ Booking not found";
      return;
    }

    const b = data.booking;
    box.innerHTML = `
      <b>🎟️ Token:</b> ${b.token}<br>
      <b>👨‍🌾 Farmer:</b> ${b.farmer_name}<br>
      <b>🌾 Crop:</b> ${b.crop}<br>
      <b>📍 Centre:</b> ${b.centre}<br>
      <b>📊 Queue:</b> ${b.queue_position}<br>
      <b>🔔 Status:</b> <strong>${b.status}</strong>
    `;
  } catch (err) {
    box.innerHTML = "❌ Backend is not running.";
  }
}

async function loadBookings() {
  try {
    const [bookingRes, statsRes] = await Promise.all([
      fetch("/api/bookings"),
      fetch("/api/stats")
    ]);

    const data = await bookingRes.json();
    const stats = await statsRes.json();

    document.getElementById("stats").innerHTML = `
      <div class="stat"><b>${stats.total}</b>Total Bookings</div>
      <div class="stat"><b>${stats.waiting}</b>Waiting</div>
      <div class="stat"><b>${stats.procured}</b>Procured</div>
    `;

    const container = document.getElementById("bookings");
    if (!data.length) {
      container.innerHTML = "<p>No farmer bookings yet.</p>";
      return;
    }

    container.innerHTML = data.map(b => `
      <div class="booking-card">
        <h3>🎟️ ${b.token}</h3>
        <p>👨‍🌾 <b>${escapeHtml(b.farmer_name)}</b> | 📱 ${escapeHtml(b.mobile)}</p>
        <p>🌾 ${escapeHtml(b.crop)} — ${b.quantity} Quintals</p>
        <p>📍 ${escapeHtml(b.centre)} | 📅 ${escapeHtml(b.booking_date)}</p>
        <p>📊 Queue: ${b.queue_position} | 🔔 <b>${escapeHtml(b.status)}</b></p>
        <div>
          <button onclick="updateStatus(${b.id}, 'In Queue')">In Queue</button>
          <button onclick="updateStatus(${b.id}, 'Verified')">Verified</button>
          <button onclick="updateStatus(${b.id}, 'Procured')">Procured</button>
          <button onclick="updateStatus(${b.id}, 'Cancelled')">Cancel</button>
        </div>
      </div>
    `).join("");
  } catch (err) {
    document.getElementById("bookings").innerHTML = "<p>❌ Backend is not running.</p>";
  }
}

async function updateStatus(id, status) {
  try {
    const res = await fetch(`/api/status/${id}`, {
      method: "PUT",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({status})
    });
    const result = await res.json();

    if (result.success) {
      loadBookings();
      checkStatus();
    } else {
      alert(result.message);
    }
  } catch (err) {
    alert("Backend connection error.");
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}

document.getElementById("booking_date").min =
  new Date().toISOString().split("T")[0];


// =========================
// CROP PHOTO PREVIEW + DEMO AI
// =========================
function previewCrop(event) {
  const file = event.target.files[0];
  if (!file) return;

  const preview = document.getElementById("cropPreview");
  preview.src = URL.createObjectURL(file);
  preview.style.display = "block";
  document.getElementById("uploadIcon").textContent = "✅";
  document.getElementById("uploadText").textContent = file.name;
}

async function analyzeCrop() {
  const photo = document.getElementById("cropPhoto").files[0];
  const crop = document.getElementById("aiCrop").value;
  const result = document.getElementById("cropResult");

  if (!photo) {
    result.innerHTML = `<div class="result-placeholder"><span>📷</span><b>Please upload a crop photo</b><p>Select a clear field/crop image.</p></div>`;
    return;
  }

  if (!crop) {
    result.innerHTML = `<div class="result-placeholder"><span>🌱</span><b>Select the crop</b><p>Choose Paddy, Maize, Cotton or Rice for the demo estimate.</p></div>`;
    return;
  }

  const formData = new FormData();
  formData.append("photo", photo);
  formData.append("crop", crop);

  result.innerHTML = `<div class="result-placeholder"><span>🔎</span><b>Analyzing...</b><p>Preparing the procurement estimate.</p></div>`;

  try {
    const res = await fetch("/api/analyze-crop", {
      method: "POST",
      body: formData
    });
    const data = await res.json();

    if (!data.success) {
      result.innerHTML = `<div class="result-placeholder"><span>❌</span><b>${data.message}</b></div>`;
      return;
    }

    result.innerHTML = `
      <div class="ai-answer">
        <span class="ai-badge">🌿 Demo Crop Analysis</span>
        <h3>${data.crop}</h3>
        <p>Estimated time until harvest/procurement readiness:</p>
        <div class="ai-days">${data.estimated_days} days</div>
        <p><b>Model confidence:</b> ${data.confidence}%</p>
        <div class="progress"><span style="width:${data.confidence}%"></span></div>
        <p>📅 Use this estimate to plan your procurement token and reduce waiting at the centre.</p>
        <p style="margin-top:10px;color:#607568">${data.note}</p>
      </div>
    `;
  } catch (err) {
    result.innerHTML = `<div class="result-placeholder"><span>⚠️</span><b>Backend is not running</b><p>Start the project with python app.py.</p></div>`;
  }
}
