# AgriSetu Android — Android Studio Project

This project converts the supplied Flask AgriSetu demo into a standalone Android app.

## What changed
- The original HTML/CSS design is preserved.
- Flask API calls were replaced with Android WebView localStorage, so the app works offline.
- Farmer bookings, status changes, and officer dashboard data persist on the device.
- Crop photo selection works through the Android file picker.
- Crop analysis remains the original demo mapping (Paddy/Rice/Maize/Cotton); no trained AI model is bundled.
- The original Flask backend is kept under `backend-reference/` for future server deployment.

## Open in Android Studio
1. Extract this ZIP.
2. Open the `AgriSetuAndroid` folder in Android Studio.
3. Let Gradle sync.
4. Use an Android emulator or connect an Android phone with USB debugging enabled.
5. Run `app`.

## Build APK
Android Studio: **Build → Generate App Bundles or APKs → Generate APKs**.

For a debug APK, the expected output is:
`app/build/outputs/apk/debug/app-debug.apk`

For a release APK, use **Build → Generate Signed App Bundle / APK** and create/select a keystore.

## Requirements
- Android Studio current stable release
- Android SDK 35
- JDK 17+ (Android Studio's bundled JDK is recommended)

## Important
This is a local/offline conversion. Multiple phones will not share booking data. For a real multi-farmer deployment, connect the app to a hosted backend/API and database.
