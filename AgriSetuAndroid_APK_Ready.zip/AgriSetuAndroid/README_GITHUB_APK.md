# AgriSetu Green Crop AI — Phone-only APK Build

This project includes a GitHub Actions workflow that builds the Android APK in the cloud. You do **not** need Android Studio on your phone.

## If your GitHub repository contains this ZIP only
1. Keep `AgriSetuAndroid_Project.zip` in the repository root.
2. Also upload the `.github/workflows/build-apk.yml` file from this project to the repository root at exactly that path.
3. The workflow in this package is designed for the extracted project folder `AgriSetuAndroid` and will build it when the project is committed directly to the repository.

## Recommended repository layout
Extract the ZIP and upload the contents so the repository root contains:

- `AgriSetuAndroid/`
- `.github/workflows/build-apk.yml`

Then open **Actions → Build AgriSetu APK → Run workflow**.

When the run finishes with a green check, open the run and download the **AgriSetu-APK** artifact. Extract the downloaded artifact ZIP and install `app-debug.apk` on Android.

The workflow uses Java 17, Android SDK 35, and Gradle 8.9. It intentionally does not depend on a missing Gradle wrapper.
