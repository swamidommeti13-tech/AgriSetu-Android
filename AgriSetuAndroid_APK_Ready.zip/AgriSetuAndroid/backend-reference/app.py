from flask import Flask, request, jsonify, render_template
from pathlib import Path
import sqlite3
from datetime import datetime

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "agrisetu.db"

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            farmer_name TEXT NOT NULL,
            mobile TEXT NOT NULL,
            village TEXT NOT NULL,
            crop TEXT NOT NULL,
            quantity REAL NOT NULL,
            centre TEXT NOT NULL,
            booking_date TEXT NOT NULL,
            token TEXT NOT NULL,
            queue_position INTEGER NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/book", methods=["POST"])
def create_booking():
    data = request.get_json(silent=True) or {}
    fields = ["farmer_name","mobile","village","crop","quantity","centre","booking_date"]
    if not all(data.get(f) for f in fields):
        return jsonify(success=False, message="Please fill all details"), 400

    try:
        quantity = float(data["quantity"])
        if quantity <= 0:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify(success=False, message="Quantity must be a valid positive number"), 400

    conn = get_db()
    count = conn.execute(
        "SELECT COUNT(*) FROM bookings WHERE booking_date=? AND centre=?",
        (data["booking_date"], data["centre"])
    ).fetchone()[0]
    queue_position = count + 1
    token = f"A-{100 + queue_position}"
    status = "Token Generated"
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cur = conn.execute("""
        INSERT INTO bookings
        (farmer_name,mobile,village,crop,quantity,centre,booking_date,
         token,queue_position,status,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    """, (
        data["farmer_name"], data["mobile"], data["village"], data["crop"],
        quantity, data["centre"], data["booking_date"], token,
        queue_position, status, created_at
    ))
    conn.commit()
    booking_id = cur.lastrowid
    conn.close()

    return jsonify(
        success=True,
        message="Token generated successfully",
        booking_id=booking_id,
        token=token,
        queue_position=queue_position,
        estimated_wait=queue_position * 8,
        status=status
    )

@app.route("/api/bookings")
def get_bookings():
    conn = get_db()
    rows = conn.execute("SELECT * FROM bookings ORDER BY id DESC").fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])

@app.route("/api/status/<int:booking_id>", methods=["PUT"])
def update_status(booking_id):
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    allowed = ["Token Generated", "In Queue", "Verified", "Procured", "Cancelled"]
    if status not in allowed:
        return jsonify(success=False, message="Invalid status"), 400

    conn = get_db()
    cur = conn.execute("UPDATE bookings SET status=? WHERE id=?", (status, booking_id))
    conn.commit()
    conn.close()

    if cur.rowcount == 0:
        return jsonify(success=False, message="Booking not found"), 404
    return jsonify(success=True, message="Status updated successfully")

@app.route("/api/status/<int:booking_id>", methods=["GET"])
def get_status(booking_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM bookings WHERE id=?", (booking_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify(success=False, message="Booking not found"), 404
    return jsonify(success=True, booking=dict(row))

@app.route("/api/stats")
def stats():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
    waiting = conn.execute("""
        SELECT COUNT(*) FROM bookings
        WHERE status IN ('Token Generated','In Queue','Verified')
    """).fetchone()[0]
    procured = conn.execute(
        "SELECT COUNT(*) FROM bookings WHERE status='Procured'"
    ).fetchone()[0]
    conn.close()
    return jsonify(total=total, waiting=waiting, procured=procured)


# =========================
# DEMO CROP PHOTO ANALYZER
# =========================
@app.route("/api/analyze-crop", methods=["POST"])
def analyze_crop():
    crop = (request.form.get("crop") or "").strip().lower()
    photo = request.files.get("photo")

    if not photo:
        return jsonify(success=False, message="Please upload a crop photo."), 400

    # Demo mapping for SIH presentation.
    # Replace this mapping with a trained computer-vision model later.
    crop_data = {
        "paddy": {"name": "Paddy", "days": 30, "confidence": 92, "note": "Crop appears suitable for procurement planning."},
        "rice": {"name": "Rice", "days": 30, "confidence": 90, "note": "Estimated remaining period is based on the selected crop."},
        "maize": {"name": "Maize", "days": 25, "confidence": 89, "note": "Estimated remaining period is based on the selected crop."},
        "cotton": {"name": "Cotton", "days": 35, "confidence": 87, "note": "Estimated remaining period is based on the selected crop."}
    }

    # For a simple demo, the farmer can choose the crop after uploading.
    # This keeps the project runnable without an external AI key.
    item = crop_data.get(crop)
    if not item:
        return jsonify(
            success=True,
            demo=True,
            message="Photo uploaded. Select the crop to get an estimated harvest/procurement window.",
            photo_name=photo.filename
        )

    return jsonify(
        success=True,
        demo=True,
        crop=item["name"],
        estimated_days=item["days"],
        confidence=item["confidence"],
        note=item["note"],
        photo_name=photo.filename
    )

if __name__ == "__main__":
    init_db()
    print("\n======================================")
    print("🌾 AGRISETU FARMER PROCUREMENT SYSTEM")
    print("======================================")
    print("🌐 http://127.0.0.1:5000")
    print("💾 SQLite database: agrisetu.db")
    print("======================================\n")
    app.run(host="0.0.0.0", port=5000, debug=True)
