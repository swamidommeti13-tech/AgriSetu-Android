# 🌾 AgriSetu Ready Demo

Simple SIH demo for the farmer procurement problem statement.

## Technology
- Frontend: HTML + CSS + JavaScript
- Backend: Python Flask
- Database: SQLite
- No Firebase required

## Run

### Windows
1. Install Python 3.
2. Open this folder in VS Code.
3. Open Terminal.
4. Run:

```bash
pip install -r requirements.txt
python app.py
```

5. Open Chrome:
http://127.0.0.1:5000

The SQLite database `agrisetu.db` is created automatically.

## Demo Flow
1. Fill farmer details.
2. Select crop, quantity, date and centre.
3. Click Generate Token.
4. Booking ID and token are generated.
5. Use Booking ID in Check Status.
6. Officer Dashboard can move status:
   Token Generated → In Queue → Verified → Procured

Keep the terminal running while using the demo.


## 🌱 New Crop Photo Feature
The green "Crop Photo → Smart Harvest Estimate" section lets a farmer:
1. Upload a crop/field photo.
2. Select the crop in demo mode.
3. Receive an estimated number of days until harvest/procurement readiness.

This is intentionally a no-API-key demo so it runs immediately. For a production SIH version, connect a trained crop classification/growth-stage model to `/api/analyze-crop`.
