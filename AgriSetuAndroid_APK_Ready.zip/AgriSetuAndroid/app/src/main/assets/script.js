const STORAGE_KEY = "agrisetu_bookings_v1";
const form = document.getElementById("bookingForm");
const statuses = ["Token Generated", "In Queue", "Verified", "Procured", "Cancelled"];

function bookings() { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
function saveBookings(items) { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); }
function setText(id, value) { document.getElementById(id).textContent = value; }
function nextId(items) { return items.reduce((m,b)=>Math.max(m, Number(b.id)||0), 0) + 1; }

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const data = {
    farmer_name: document.getElementById("farmer_name").value.trim(),
    mobile: document.getElementById("mobile").value.trim(),
    village: document.getElementById("village").value.trim(),
    crop: document.getElementById("crop").value,
    quantity: document.getElementById("quantity").value,
    centre: document.getElementById("centre").value,
    booking_date: document.getElementById("booking_date").value
  };
  if (!data.farmer_name || !/^\d{10}$/.test(data.mobile) || !data.village || !data.crop || !data.quantity || Number(data.quantity)<=0 || !data.centre || !data.booking_date) {
    alert("Please fill all details correctly."); return;
  }
  const items = bookings();
  const queue = items.filter(b => b.booking_date === data.booking_date && b.centre === data.centre).length + 1;
  const id = nextId(items);
  const token = `A-${100 + queue}`;
  const booking = {...data, id, quantity:Number(data.quantity), token, queue_position:queue, status:"Token Generated", created_at:new Date().toISOString()};
  items.unshift(booking); saveBookings(items);
  document.getElementById("result").style.display = "block";
  setText("token", token); setText("r_id", id); setText("r_farmer", data.farmer_name); setText("r_crop", data.crop);
  setText("r_quantity", data.quantity); setText("r_centre", data.centre); setText("r_date", data.booking_date); setText("r_queue", queue);
  setText("r_wait", queue * 8); setText("r_status", booking.status); document.getElementById("status_id").value=id;
  document.getElementById("result").scrollIntoView({behavior:"smooth"});
});

function checkStatus() {
  const id = Number(document.getElementById("status_id").value), box=document.getElementById("statusResult");
  if (!id) { box.innerHTML="❌ Enter Booking ID"; return; }
  const b=bookings().find(x=>Number(x.id)===id);
  if (!b) { box.innerHTML="❌ Booking not found"; return; }
  box.innerHTML=`<b>🎟️ Token:</b> ${escapeHtml(b.token)}<br><b>👨‍🌾 Farmer:</b> ${escapeHtml(b.farmer_name)}<br><b>🌾 Crop:</b> ${escapeHtml(b.crop)}<br><b>📍 Centre:</b> ${escapeHtml(b.centre)}<br><b>📊 Queue:</b> ${b.queue_position}<br><b>🔔 Status:</b> <strong>${escapeHtml(b.status)}</strong>`;
}

function loadBookings() {
  const data=bookings();
  const waiting=data.filter(b=>["Token Generated","In Queue","Verified"].includes(b.status)).length;
  const procured=data.filter(b=>b.status==="Procured").length;
  document.getElementById("stats").innerHTML=`<div class="stat"><b>${data.length}</b>Total Bookings</div><div class="stat"><b>${waiting}</b>Waiting</div><div class="stat"><b>${procured}</b>Procured</div>`;
  const container=document.getElementById("bookings");
  if(!data.length){container.innerHTML="<p>No farmer bookings yet.</p>";return;}
  container.innerHTML=data.map(b=>`<div class="booking-card"><h3>🎟️ ${escapeHtml(b.token)}</h3><p>👨‍🌾 <b>${escapeHtml(b.farmer_name)}</b> | 📱 ${escapeHtml(b.mobile)}</p><p>🌾 ${escapeHtml(b.crop)} — ${b.quantity} Quintals</p><p>📍 ${escapeHtml(b.centre)} | 📅 ${escapeHtml(b.booking_date)}</p><p>📊 Queue: ${b.queue_position} | 🔔 <b>${escapeHtml(b.status)}</b></p><div><button onclick="updateStatus(${b.id}, 'In Queue')">In Queue</button><button onclick="updateStatus(${b.id}, 'Verified')">Verified</button><button onclick="updateStatus(${b.id}, 'Procured')">Procured</button><button onclick="updateStatus(${b.id}, 'Cancelled')">Cancel</button></div></div>`).join("");
}
function updateStatus(id,status){ const items=bookings(); const b=items.find(x=>Number(x.id)===Number(id)); if(!b)return; b.status=status; saveBookings(items); loadBookings(); checkStatus(); }
function escapeHtml(value){return String(value).replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[ch]));}

document.getElementById("booking_date").min=new Date().toISOString().split("T")[0];
function previewCrop(event){const file=event.target.files[0];if(!file)return;const preview=document.getElementById("cropPreview");preview.src=URL.createObjectURL(file);preview.style.display="block";document.getElementById("uploadIcon").textContent="✅";document.getElementById("uploadText").textContent=file.name;}
function analyzeCrop(){const photo=document.getElementById("cropPhoto").files[0],crop=document.getElementById("aiCrop").value,result=document.getElementById("cropResult");if(!photo){result.innerHTML=`<div class="result-placeholder"><span>📷</span><b>Please upload a crop photo</b><p>Select a clear field/crop image.</p></div>`;return;}if(!crop){result.innerHTML=`<div class="result-placeholder"><span>🌱</span><b>Select the crop</b><p>Choose Paddy, Maize, Cotton or Rice for the demo estimate.</p></div>`;return;}const map={paddy:["Paddy",30,92,"Crop appears suitable for procurement planning."],rice:["Rice",30,90,"Estimated remaining period is based on the selected crop."],maize:["Maize",25,89,"Estimated remaining period is based on the selected crop."],cotton:["Cotton",35,87,"Estimated remaining period is based on the selected crop."]};const d=map[crop];result.innerHTML=`<div class="ai-answer"><span class="ai-badge">🌿 Demo Crop Analysis</span><h3>${d[0]}</h3><p>Estimated time until harvest/procurement readiness:</p><div class="ai-days">${d[1]} days</div><p><b>Model confidence:</b> ${d[2]}%</p><div class="progress"><span style="width:${d[2]}%"></span></div><p>📅 Use this estimate to plan your procurement token and reduce waiting at the centre.</p><p style="margin-top:10px;color:#607568">${d[3]}</p></div>`;}
